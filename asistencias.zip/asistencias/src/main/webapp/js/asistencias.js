function editar(index) {
    document.getElementById(index).querySelectorAll("input[type=text],input[type=email]").forEach((element) => {
        element.disabled = false;
    });
    document.getElementById(index).querySelectorAll("button.d-none").forEach((element) => {
        element.classList.remove("d-none");
    });
    document.getElementById(index).querySelector("button.btn-success").classList.add("d-none");
    document.getElementById(index).querySelector("input[type=text]").focus();
}

function cancelar(index) {
    document.getElementById(index).querySelectorAll("input[type=text],input[type=email]").forEach((element) => {
        element.disabled = true;
    });
    document.getElementById(index).querySelectorAll("button:not(.d-none)").forEach((element) => {
        element.classList.add("d-none");
    });
    document.getElementById(index).querySelector("button.btn-success").classList.remove("d-none");
}